# com_cettselecao
Componente responsavel pela melhorar na performance das listas de inscrições do sistema de seleção
