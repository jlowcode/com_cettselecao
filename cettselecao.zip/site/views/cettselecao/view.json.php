<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_cettselecao
 *
 * @copyright   Copyright (C) 2005 - 2019 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * View file for responding to Ajax request for performing
 */

 
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
class CettSelecaoViewCettSelecao extends JViewLegacy
{
	function display($tpl = null)
	{
		$ud = '';
	}

	function list($tpl = null) {
		$aa = '';
	}
}